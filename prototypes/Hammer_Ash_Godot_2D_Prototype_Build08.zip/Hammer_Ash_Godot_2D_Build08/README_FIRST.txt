HAMMER & ASH: UPRISING — BUILD 08 / THE THREE-ROOM CHAIN
Godot 4.x / 2D / full runnable project (no external assets).

RUN
1. Extract the archive to its own folder.
2. In Godot Project Manager choose Import > project.godot.
3. Open the project and press F5.

GOAL: CLEAR THREE ROOMS IN ORDER
ROOM 1 / KENNEL BREACH
  Five original player operatives versus seven 4-HP, 5-tile-moving hounds
  and a KGB Biotechnician. Support AI is less inclined to hide remotely.
ROOM 2 / KGB CORDON
  Six ranged KGB defenders on a fortified 22x16 bunker map.
  Cover, sight lines and Overwatch matter.
ROOM 3 / ELITE RESPONSE
  Three hounds, three KGB riflemen, and a tough 15-HP, 4-ARM,
  3-AP elite enforcer on a compact 18x14 map.
  Win by eliminating every enemy in all three rooms. Failure if the
  entire squad becomes incapacitated in any room.

INTER-ROOM RULES
- HP damage persists across rooms. No automatic HP restoration for standing operatives.
- Operatives downed for the first time in a room are unable to act for
  its remainder. On successful clearance, they return in the next room
  with ceil(50% max HP) and one down recorded.
- A SECOND down permanently eliminates that operative for the chain.
- If all five are down/dead, the whole mission fails.
- Armour refreshes to full at the start of each room (as during combat).
- AP, temporary buffs/debuffs and ability cooldowns reset between rooms.
- No free HP healing: the Biochemist's Field Treatment costs 1 AP,
  and can be used tactically before clearing the final enemy.
- No equipment changing between rooms. No extraction in an active room.
- Room clear PAUSES on an inter-room screen; press ENTER or click CONTINUE.
- R starts a new mission from Room 1, even after entering later rooms.
- C/T may not skip rooms or change maps during this chained mission.

CONTROLS
Left click: select/move/attack; Q ability; O Overwatch; 1–5 unit select;
TAB cycle; SPACE end player turn; H enemy threat overlay;
F weapon range; L damage ledger; UP/DOWN scroll ledger;
A toggle armour (restarts entire chain); I toggle AI (restarts chain);
D AI decisions debug; V after-action report/battlefield after completion;
R restart chain; ENTER proceed on room-clear screen; ESC cancel target.

PLAYTEST
1. Lose some HP in Room 1. After clearing, check inter-room HP and
   observe EXACTLY the same value at Room 2 start.
2. Confirm armour restores but HP does not; AP and ability cooldowns reset.
3. Down one operative (but keep the squad alive). Check their half-HP
   return next room, and permanent loss if downed again.
4. Complete all three rooms without restarting: only then should the
   game declare MISSION COMPLETE.
5. Confirm the defensive KGB room feels different from the hound room,
   and that the elite's three AP creates a tougher final challenge.
6. Use L to verify per-room damage and V to inspect the end report.

STATUS
Prototype proof of concept. Source files and positions have been
statically checked, but local Godot runtime playtest is required.

HAMMER & ASH: UPRISING — BUILD 08.2 / ROOM-BY-ROOM SQUAD ACTIVITY
Godot 4.x / 2D / full standalone project (no art assets required).

HOW TO RUN
1. Extract the ZIP to a new, separate folder (keep Build 08.1 as a backup).
2. Open Godot Project Manager > Import > project.godot.
3. Open the project and press F5.

MISSION STRUCTURE (unchanged)
Room 1: Kennel Breach — seven hounds and a KGB Biotechnician.
Room 2: KGB Cordon — six ranged KGB defenders and a radio transmitter.
Room 3: Elite Response — three hounds, three rifles and an elite enforcer.
Only clearing every enemy in all THREE rooms wins the mission.
Squad HP and previous downs persist. Armour/AP/cooldowns reset each room.
First-down recovery is half maximum HP at the next room. A second down
permanently eliminates an operative from this mission.

NEW ROOM 2 SECONDARY OBJECTIVE — RADIO TRANSMITTER
- Radio Transmitter is a GOLD 'TX' object near the KGB defensive line.
- It has exactly 2 HP, no armour, and occupies a tile while intact.
- With a player operative selected, CLICK the radio to attack it.
    * From an adjacent tile: an automatic 1-AP melee strike (2 damage).
    * At greater distances: a 1-AP basic weapon shot, requiring weapon
      range and clear line of sight. Hover the radio to preview damage.
    * Razor's Area Shred also damages the transmitter if included in its arc.
- DESTROY it by the END OF THE THIRD PLAYER TURN in Room 2.
- If still standing when you press End Turn in round 3, the alert is sent.
- If you clear all enemies and leave Room 2 without destroying the radio,
  that also counts as an alert, even if three turns have not elapsed.
- Destroying it AFTER the deadline does not cancel an already sent alert.
- The radio is an OPTIONAL objective: room clearance still only requires
  defeating the six defenders. Destroying it does not end the room.
- SUCCESS: Room 3 retains the standard 3 hounds, 3 rifles, 1 elite.
- FAILURE: Room 3 adds 3 more hounds, for SIX hounds total.
- Room 2 sidebar and transition screen show radio and alert status.
- Objective hits appear in the [L] hit ledger. They are excluded from
  enemy-unit damage totals so the combat-damage audit remains accurate.

NEW: ROOM-BY-ROOM SQUAD ACTIVITY REPORT
After Rooms 1 and 2 are cleared, the transition screen lists EACH of your five
operatives with:
- Basic attacks performed (including shots/melee attacks on the transmitter)
- Number of normal movement orders and actual tiles travelled
- Overwatch stances reserved and Overwatch attacks triggered
- Each named signature ability and number of activations
- Actual HP + armour damage dealt and received, kills, HP damage,
  healing, buffs, radio transmitter damage, and carried HP
After final victory or mission failure, press P to open the same report.
Use LEFT/RIGHT to browse completed room reports and P to return to the
full after-action screen. Each room is snapshotted when it ends and does not
change when you proceed. L still opens the hit ledger for the CURRENT room.
Area Shred is ONE ability activation even when it hits multiple enemies;
its damage is the sum of HP and armour actually removed from all targets.
No damage / AP / objective / AI balance changes in Build 08.2.

COSMETIC FIX (PRESERVED)
The mission completion / failure popup wraps to two shorter centered lines.

CONTROLS
Left-click select/move/attack or attack the radio; Q signature ability;
O Overwatch; 1-5 select operative; TAB next; SPACE end player turn;
H enemy threat; F range; L hit ledger; D AI debug; R restart full chain;
ENTER advance at room-clear screen; P view unit actions after mission ends;
LEFT/RIGHT change reviewed room while viewing P; V report/battlefield after outcome.
A armour / I AI mode toggle (both restart chain).

PLAYTEST THE TWO RADIO BRANCHES
A. First run: destroy TX within three player turns in Room 2. Clear
   remaining guards, advance and confirm ONLY three hounds in Room 3.
B. Second run: ignore TX and clear Room 2, or let turn 3 expire. Advance
   and confirm SIX hounds in Room 3 (three original + three extra).
C. In both runs, check that squad HP, previous downs and other inter-room
   rules still behave as in Build 08.
D. Complete Room 3 and confirm the shortened victory popup fits.

STATUS
Code and map spawns have been statically checked. This sandbox cannot
run the Godot window, so please verify behavior with F5 in Godot.

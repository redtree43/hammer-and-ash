HAMMER & ASH: UPRISING — COMBAT PROTOTYPE BUILD 07.1
GODOT 4.x / 2D — OVERWATCH, COMBAT LEDGER, TWO SCENARIOS

INSTALL / RUN
1. Extract this ZIP into a new folder (keep your working Build 07 folder).
2. Godot Project Manager > Import > choose project.godot in the extracted folder.
3. Open and press F5. No external plugins or art assets required.

WHAT CHANGED FROM BUILD 07
- Removed Guard (G) as a universal action. G no longer does anything.
  A class-specific automatic melee retaliation could be added later as an
  unlockable passive (NOT implemented in this build).
- Overwatch (O) is unchanged and remains an effective anti-horde action.
- Fixed H threat-preview status text overlapping attack previews.
- Each hit now shows temporary floating HP/ARM damage above the target.
- Press L to open a complete hit-by-hit ledger during or after combat.
  UP/DOWN scroll through attack records, newest first; L or ESC closes.
  The ledger tracks every damage event, separately for Area Shred targets,
  showing round, attacker, target, ability, cover reduction, actual ARM/HP
  removed and running damage for each side.
- The After-Action Report displays an audit status. RECONCILED means the
  damage totals agree between attacker stats, recipient stats, ability totals
  and all recorded hits. If you ever see MISMATCH, report it.

IMPORTANT DAMAGE ACCOUNTING
- Only actual points removed from ARM and HP count as damage. Overkill is not
  counted. Fortify and healing are counted as support, not as damage.
- Armour refreshes at the start of each faction phase; cumulative armour
  damage can therefore exceed a unit's maximum armour.
- A hit that removes ARM 2 and HP 1 contributes 3 damage to the report.
- Enemy support heals HP, but healing does NOT subtract from the enemy's
  total damage received over the encounter.

SCENARIOS
C: switch between scenarios (restarts the battle)
1. Horde — five operatives vs nine fast 4-HP hounds, a Biotechnician and
   four ranged KGB soldiers. T switches between 22x16 and 18x14 layouts.
2. Command Bunker — five operatives vs Commander Voronov, three KGB soldiers,
   one Biotechnician and three hounds on a fortified map. T has no effect here.
The boss remains stronger but his AI/abilities are unchanged from Build 07.

CONTROLS
Left click: select a blue unit, move to a green square, attack an enemy.
1–5 / TAB: select operative / next operative
Q: use selected unit's signature ability (follow targeting instructions)
O: reserve one AP for Overwatch; one reaction when a moving enemy enters a
   valid basic-weapon shot, subject to cover, LOS and armour.
H: enemy next-phase threat preview; hover an enemy while H is enabled
F: toggle basic attack range outline and enemy firing indicators
L: open/close detailed damage ledger; UP/DOWN scroll, ESC close
SPACE: end player turn
R: restart current scenario
C: switch scenarios (restart)
T: toggle map size in the Horde scenario (restart)
A: toggle armour and restart
I: toggle tactical/legacy AI and restart
D: toggle AI reasoning/debug messages
V: after battle, switch between battlefield and After-Action Report
ESC: cancel ability targeting (or close the damage ledger)

PRESERVED RULES
- 3 AP per player operative; 1 AP per basic attack; 4 tiles / 1 AP movement.
- Hounds: 5-tile movement per AP, 4 HP, 2 AP; charge without self-preservation.
- Enemy cover-aware planner, supporter AI, and boss self-preservation remain.
- Directional shared-edge cover, full armour phase reset, deterministic hits.
- Razor Area Shred: charge 0–3 path tiles then sweep 3 consecutive neighbouring
  tiles for 2 damage each; total 2 AP. Charge movement can trigger reactions.
- Sentinel Fortify: 1 AP, +2 temporary ARM to one ally plus Sentinel.
- Engineer Arc Disruptor: 1 AP, one full next-turn cooldown.
- Biochemist Field Treatment: 1 AP, heals up to 3 HP, same cooldown.
- Tile-by-tile movement, range/LOS indicators and after-action statistics.

SUGGESTED TEST
1. Play Scenario 1 with multiple Overwatch users. Watch floating ARM and HP
   numbers when a hound enters shooting range; open L and compare events.
2. Use Razor Area Shred against 2–3 adjacent hounds. In L, check that each
   affected enemy has a separate event and the sum matches the report.
3. Toggle H on and hover a target while reading attack preview. The H text
   must NOT cover the predicted damage text.
4. After a win or loss, press L on the report; verify RECONCILED and inspect
   both teams' damage totals and the names of attacks responsible.
5. Press G: no universal Guard should activate or spend AP.

LIMITATION
This is a proof-of-concept, not a finished UI. The output ZIP and code structure
have been checked but it still needs real Godot runtime testing on your computer.

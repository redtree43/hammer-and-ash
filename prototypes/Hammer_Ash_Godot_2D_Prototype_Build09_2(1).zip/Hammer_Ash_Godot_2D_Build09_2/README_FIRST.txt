HAMMER & ASH: UPRISING — BUILD 09.2 / ENVIRONMENTAL COMBAT INSPECTOR
Godot 4.7+ / 2D / self-contained project. No external art assets.

RUN
1. Extract the ZIP to its own folder.
2. Godot Project Manager > Import > choose project.godot.
3. Open and press F5.

WHAT CHANGED
- Replaced most of the huge right-side squad/enemy lists with a compact
  five-operative selector (click a tab, or 1-5 / Tab).
- Selected operative appears in the right panel with name, HP, ARM, AP,
  weight, attack damage/range, movement, statuses and Q ability.
- Hover a battlefield enemy for its name, HP, ARM, AP, weight, statuses,
  attack and movement profile, and the selected unit's shot preview.
- Hover an explosive barrel or radio transmitter to inspect it.
- All three rooms now contain exactly ONE fuel barrel and ONE waste barrel.
  These are separated and will not automatically chain-react with each other.
- Select destructible cover sections retain 2 HP light / 5 HP reinforced.
  HP is NOT displayed to the player; only a small breakable marker is drawn.
- If Burning, Irradiated or Shocked is already active, entering that same
  hazard type again does NOT deal additional entry damage or refresh status.
  Existing ongoing effect ticks continue on their normal schedule.

UNCHANGED COMBAT / KEYS
- [F6] Room 1 / [F7] Room 2 / [F8] Room 3: developer-only room jump,
  fresh squad, no prior radio consequence.
- Clear each room normally to preserve HP, downs and radio consequences.
- [Q] Special, [B] Sentinel straight-line Breach, [O] Overwatch,
  [F] ranges, [H] threat, [L] damage ledger, [P] room activity after victory,
  [V] final report, [A] armour, [I] tactical AI, [R] restart, [Space] end turn.
- Razor Area Shred destroys LIGHT cover only; Sentinel Breach destroys
  LIGHT and REINFORCED cover and displaces lighter targets for 5 damage.
- Directly targetable fuel and radiation-waste barrels can still trigger
  explosions, knockback and 3-round environmental hazards.
- Full three-room mission and optional Room 2 radio transmitter remain.

IMPORTANT TESTING NOTE
The project archive and source underwent automated static checks. The
Godot engine was not available in the build environment, so successful
Godot import/F5 execution still needs verification in your local editor.
See CHANGELOG_09_2.txt and README_BUILD09_2.txt for detail.
